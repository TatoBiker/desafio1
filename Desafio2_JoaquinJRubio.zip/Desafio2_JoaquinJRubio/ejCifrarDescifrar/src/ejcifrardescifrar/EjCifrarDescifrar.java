
package ejcifrardescifrar;

import java.util.Scanner;

/**
 * Proyecto básico, des/cifrar una palabra y comentarios en Java
 * 
 * @author Joaquín J. Rubio Baños
 * @version 1.0
 */


public class EjCifrarDescifrar {

    /**
     * En el main tenemos bucle de utilidades se ejecuta y llama a dos funciones:
     * - codificar
     * - decodificar
     * @param args el main
     */
    public static void main(String[] args) {
        /** Declaracion de variables **/
        Scanner sc=new Scanner(System.in);  //Scanner 
        boolean salir=false;                //controlar salida 
        char let;                           //letra para modificar
        String nCad, cad;                   //palabra original (cad) y la obtenida (nCad)
        
        System.out.print("Hola!");
        
        /**
         *  Bucle dedicado a la interacción entre pc y usuario
         */
        do {
            System.out.println("Escribe una palabra");
            cad= sc.nextLine();
            
            //Elegir la opción deseada
            System.out.println("Si quieres cifrar pulsa 'C'");
            System.out.println("Si quieres descifrar pulsa 'D'");
            let=sc.nextLine().charAt(0);
            
            //Cifrar / Descifrar según la opción
            if (let=='C' || let=='c') {
                nCad=cifrar(cad);
                System.out.println(nCad);
            }else{
                if (let=='D' || let=='d') {
                    nCad=descifrar(cad);
                    System.out.println(nCad);
                }else{
                    System.out.println("Opción incorrecta");
                }
            }
            
            //Controlar la salida preguntando al usuario
            System.out.println("Quieres salir? (S/N)");
            String opcion=sc.nextLine();
            
            if (opcion.equalsIgnoreCase("s")) {
                salir=true;
            }else{
                //Limpiar pantalla
                for (int i = 0; i < 10; i++) {
                    System.out.println("");
                }
            }
        } while (!salir);
        
        
    }

    /**
     * 
     * @param cad palabra original
     * @return devuelve la palabra modificada por codigo ascii
     * @throws no tiene pues están todas controladas
     */
    private static String cifrar(String cad) {
        String c="";
        char l;
        int n;
        for (int i = 0; i < cad.length(); i++) {
            l=cad.charAt(i);
            n=(int)l;
            n++;
            l=(char)n;
            c+=l;
        }
        return c;
    }

    /**
     * 
     * @param cad palabra modificada
     * @return devuelve la palabra original por codigo ascii
     * @throws no tiene pues están todas controladas
     */
    private static String descifrar(String cad) {
        String c="";
        char l;
        int n;
        for (int i = 0; i < cad.length(); i++) {
            l=cad.charAt(i);
            n=(int)l;
            n--;
            l=(char)n;
            c+=l;
        }
        return c;
    }

    
}
